/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.ApplicantFacadeLocal;
import za.ac.tut.entities.Applicant;

/**
 *
 * @author maton
 */
public class replyApplicantServlet extends HttpServlet {
@EJB
    private ApplicantFacadeLocal afl;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Long id = Long.valueOf(request.getParameter("id"));
        String status = request.getParameter("status");
        
        Applicant a = afl.find(id);
        
        Applicant applicant = modifyStatus(a, status);
        afl.edit(applicant);
        
        request.setAttribute("applicant", applicant);
        
        RequestDispatcher disp = request.getRequestDispatcher("ReplyApplicant.jsp");
        disp.forward(request, response);
    }
    
    private Applicant modifyStatus(Applicant a,String status){
        a.setStatus(status);
        return a;
    }
   

    

}
