/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.ApplicantFacadeLocal;
import za.ac.tut.entities.Applicant;

/**
 *
 * @author maton
 */
public class trackApplicationServlet extends HttpServlet {

     @EJB
     private ApplicantFacadeLocal apl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long id = Long.valueOf(request.getParameter("id"));
        
        Applicant applicant = apl.find(id);
        String status = applicant.getStatus();
        
        request.setAttribute("status", status);
        request.setAttribute("id", id);
        
        
        RequestDispatcher disp = request.getRequestDispatcher("trackApplicationOutcome.jsp");
        disp.forward(request, response);
    }

    

}
